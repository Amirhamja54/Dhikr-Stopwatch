# Dhikr Stopwatch – setup

1. Create the project (any Flutter stable):
   flutter create --platforms=android --org com.example dhikr_stopwatch
2. Copy `android/` and `lib/` from this folder into the project (merge, overwrite).
3. Delete `test/widget_test.dart` (it references the default counter app).
4. flutter run   -> then long-press home screen > Widgets > Dhikr Stopwatch.

If you use a different applicationId, change `package` in the 5 Kotlin files
and move them to the matching folder.
