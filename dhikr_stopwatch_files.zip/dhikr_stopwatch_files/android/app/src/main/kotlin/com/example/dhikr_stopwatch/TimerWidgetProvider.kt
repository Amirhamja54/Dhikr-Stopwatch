package com.example.dhikr_stopwatch

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent

abstract class TimerWidgetProvider : AppWidgetProvider() {
    abstract val timerId: String

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.refresh(context, timerId)
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            WidgetUpdater.ACTION_TOGGLE -> {
                if (TimerStore.isRunning(context, timerId)) TimerStore.pause(context, timerId)
                else TimerStore.start(context, timerId)
                WidgetUpdater.refresh(context, timerId)
            }
            WidgetUpdater.ACTION_RESET -> {
                TimerStore.reset(context, timerId)
                WidgetUpdater.refresh(context, timerId)
            }
            WidgetUpdater.ACTION_REFRESH -> WidgetUpdater.refresh(context, timerId)
            else -> super.onReceive(context, intent)
        }
    }

    override fun onDisabled(context: Context) {
        WidgetUpdater.cancelRefresh(context, timerId)
    }
}

class DuroodWidgetProvider : TimerWidgetProvider() {
    override val timerId = TimerStore.DUROOD
}

class IstighfarWidgetProvider : TimerWidgetProvider() {
    override val timerId = TimerStore.ISTIGHFAR
}
