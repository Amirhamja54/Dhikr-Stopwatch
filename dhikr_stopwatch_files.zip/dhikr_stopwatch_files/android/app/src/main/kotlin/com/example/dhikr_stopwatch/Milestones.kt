package com.example.dhikr_stopwatch

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.RingtoneManager
import android.os.Build
import android.os.SystemClock

/**
 * Alarm + vibration at every 500 count (longer vibration at every 1000).
 * One inexact alarm is kept scheduled for the next milestone while a timer runs.
 */
object Milestones {
    const val STEP = 500L
    const val ACTION = "com.example.dhikr_stopwatch.ACTION_MILESTONE"
    const val EXTRA_ID = "timer_id"

    private const val CH_500 = "milestone_500"
    private const val CH_1000 = "milestone_1000"

    private fun pending(ctx: Context, id: String): PendingIntent {
        val intent = Intent(ctx, MilestoneReceiver::class.java)
            .setAction(ACTION)
            .putExtra(EXTRA_ID, id)
        return PendingIntent.getBroadcast(
            ctx, if (id == TimerStore.DUROOD) 20 else 21, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Cancels the old alarm and, if the timer is running, schedules the next milestone. */
    fun reschedule(c: Context, id: String) {
        val ctx = c.applicationContext
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(ctx, id)
        am.cancel(pi)
        if (!TimerStore.isRunning(ctx, id)) return

        val elapsed = TimerStore.elapsed(ctx, id)
        val next = (TimerStore.count(id, elapsed) / STEP + 1) * STEP
        val elapsedAtNext = next * TimerStore.periodMs(id) / 100
        val wait = (elapsedAtNext - elapsed).coerceAtLeast(1000L) + 300L
        val at = SystemClock.elapsedRealtime() + wait
        if (Build.VERSION.SDK_INT >= 23) {
            am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi)
        } else {
            am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi)
        }
    }

    fun onFire(c: Context, id: String) {
        val ctx = c.applicationContext
        if (TimerStore.isRunning(ctx, id)) {
            val count = TimerStore.count(id, TimerStore.elapsed(ctx, id))
            val milestone = count / STEP * STEP
            if (milestone > 0 && milestone > TimerStore.lastMilestone(ctx, id)) {
                TimerStore.setLastMilestone(ctx, id, milestone)
                notifyMilestone(ctx, id, milestone)
            }
        }
        reschedule(ctx, id)
        WidgetUpdater.refresh(ctx, id)
    }

    @Suppress("DEPRECATION")
    private fun notifyMilestone(ctx: Context, id: String, milestone: Long) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val big = milestone % 1000L == 0L
        val name = if (id == TimerStore.DUROOD) "Durood" else "Istighfar"
        val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        val pattern = if (big) longArrayOf(0, 800, 300, 800, 300, 800) else longArrayOf(0, 400, 200, 400)

        val builder: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            val channelId = if (big) CH_1000 else CH_500
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val ch = NotificationChannel(
                channelId,
                if (big) "Every 1000 count" else "Every 500 count",
                NotificationManager.IMPORTANCE_HIGH
            )
            ch.setSound(sound, attrs)
            ch.enableVibration(true)
            ch.vibrationPattern = pattern
            nm.createNotificationChannel(ch) // no-op if it already exists
            builder = Notification.Builder(ctx, channelId)
        } else {
            builder = Notification.Builder(ctx)
                .setSound(sound, AudioManager.STREAM_ALARM)
                .setVibrate(pattern)
                .setPriority(Notification.PRIORITY_HIGH)
        }

        builder
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("$name: $milestone")
            .setContentText("Count $milestone reached")
            .setAutoCancel(true)

        ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)?.let { launch ->
            builder.setContentIntent(
                PendingIntent.getActivity(
                    ctx, 30, launch,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
        }
        nm.notify(if (id == TimerStore.DUROOD) 1001 else 1002, builder.build())
    }
}

class MilestoneReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra(Milestones.EXTRA_ID) ?: return
        Milestones.onFire(context, id)
    }
}
