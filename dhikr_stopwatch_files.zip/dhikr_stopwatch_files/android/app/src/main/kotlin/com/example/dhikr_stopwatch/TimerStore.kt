package com.example.dhikr_stopwatch

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Single source of truth for both timers. Widgets and the Flutter screen
 * both read/write here, so they can never disagree.
 *
 * State is wall-clock based (startedAt + accumulated), so it survives
 * process death and phone restarts.
 */
object TimerStore {
    const val DUROOD = "durood"
    const val ISTIGHFAR = "istighfar"
    val ALL = listOf(DUROOD, ISTIGHFAR)

    private const val PREFS = "dhikr_timers"

    private fun prefs(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isRunning(c: Context, id: String) = prefs(c).getBoolean("$id.running", false)

    private fun startedAt(p: SharedPreferences, id: String, fallback: Long) =
        p.getLong("$id.startedAt", fallback)

    /** Elapsed time of the current run (what the widget shows). */
    fun elapsed(c: Context, id: String, now: Long = System.currentTimeMillis()): Long {
        val p = prefs(c)
        val acc = p.getLong("$id.acc", 0L)
        return if (p.getBoolean("$id.running", false)) {
            acc + (now - startedAt(p, id, now)).coerceAtLeast(0L)
        } else acc
    }

    /** Lifetime total including the run in progress. */
    fun lifetime(c: Context, id: String, now: Long = System.currentTimeMillis()): Long {
        val p = prefs(c)
        val live = if (p.getBoolean("$id.running", false))
            (now - startedAt(p, id, now)).coerceAtLeast(0L) else 0L
        return p.getLong("$id.lifetime", 0L) + live
    }

    @Synchronized
    fun start(c: Context, id: String, now: Long = System.currentTimeMillis()) {
        val p = prefs(c)
        if (p.getBoolean("$id.running", false)) return
        p.edit().putBoolean("$id.running", true).putLong("$id.startedAt", now).commit()
    }

    @Synchronized
    fun pause(c: Context, id: String, now: Long = System.currentTimeMillis()) {
        val p = prefs(c)
        if (!p.getBoolean("$id.running", false)) return
        val from = startedAt(p, id, now)
        val e = p.edit()
        e.putBoolean("$id.running", false)
        e.putLong("$id.acc", p.getLong("$id.acc", 0L) + (now - from).coerceAtLeast(0L))
        record(p, e, id, from, now)
        e.commit()
    }

    /** Resets the current run only. Lifetime and daily stats are kept. */
    @Synchronized
    fun reset(c: Context, id: String, now: Long = System.currentTimeMillis()) {
        val p = prefs(c)
        val e = p.edit()
        if (p.getBoolean("$id.running", false)) {
            record(p, e, id, startedAt(p, id, now), now)
        }
        e.putBoolean("$id.running", false).putLong("$id.acc", 0L).putLong("$id.startedAt", 0L)
        e.commit()
    }

    /** Newest first: index 0 = today. Each entry = (yyyy-MM-dd, millis). */
    fun daily(c: Context, id: String, days: Int, now: Long = System.currentTimeMillis()): List<Pair<String, Long>> {
        val p = prefs(c)
        val running = p.getBoolean("$id.running", false)
        val from = startedAt(p, id, now)
        val out = ArrayList<Pair<String, Long>>()
        var dayStart = startOfDay(now)
        repeat(days) {
            val next = shiftDay(dayStart, 1)
            var ms = p.getLong(dayKey(id, dayStart), 0L)
            if (running) ms += (minOf(now, next) - maxOf(from, dayStart)).coerceAtLeast(0L)
            out.add(dateStr(dayStart) to ms)
            dayStart = shiftDay(dayStart, -1)
        }
        return out
    }

    // Adds [from, to] to lifetime and splits it across calendar days.
    private fun record(p: SharedPreferences, e: SharedPreferences.Editor, id: String, from: Long, to: Long) {
        if (to <= from) return
        e.putLong("$id.lifetime", p.getLong("$id.lifetime", 0L) + (to - from))
        var dayStart = startOfDay(from)
        while (dayStart < to) {
            val next = shiftDay(dayStart, 1)
            val seg = minOf(to, next) - maxOf(from, dayStart)
            if (seg > 0) {
                val k = dayKey(id, dayStart)
                e.putLong(k, p.getLong(k, 0L) + seg)
            }
            dayStart = next
        }
    }

    private fun startOfDay(t: Long): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = t
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    private fun shiftDay(dayStart: Long, delta: Int): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = dayStart
        cal.add(Calendar.DAY_OF_MONTH, delta)
        return cal.timeInMillis
    }

    private fun dateStr(dayStart: Long) =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(dayStart))

    private fun dayKey(id: String, dayStart: Long) = "$id.day.${dateStr(dayStart)}"
}
