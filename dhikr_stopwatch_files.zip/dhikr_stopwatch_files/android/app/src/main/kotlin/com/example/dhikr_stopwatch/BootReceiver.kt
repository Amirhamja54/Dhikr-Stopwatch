package com.example.dhikr_stopwatch

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** After a reboot the launcher's cached Chronometer base is stale; rebuild it from saved state. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        WidgetUpdater.refreshAll(context)
    }
}
