package com.example.dhikr_stopwatch

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "dhikr/timers")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "snapshot" -> result.success(TimerStore.ALL.associateWith { snapshot(it) })
                    "requestNotificationPermission" -> {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        ) {
                            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
                        }
                        result.success(null)
                    }
                    "start", "pause", "reset" -> {
                        val id = call.argument<String>("id")
                        if (id == null || id !in TimerStore.ALL) {
                            result.error("bad_id", "Unknown timer id", null)
                        } else {
                            when (call.method) {
                                "start" -> TimerStore.start(this, id)
                                "pause" -> TimerStore.pause(this, id)
                                else -> TimerStore.reset(this, id)
                            }
                            WidgetUpdater.refresh(this, id)
                            result.success(snapshot(id))
                        }
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun snapshot(id: String): Map<String, Any> {
        val now = System.currentTimeMillis()
        return mapOf(
            "running" to TimerStore.isRunning(this, id),
            "elapsedMs" to TimerStore.elapsed(this, id, now),
            "lifetimeMs" to TimerStore.lifetime(this, id, now),
            "daily" to TimerStore.daily(this, id, 7, now).map { mapOf("date" to it.first, "ms" to it.second) }
        )
    }
}
