package com.example.dhikr_stopwatch

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import java.util.Locale

object WidgetUpdater {
    const val ACTION_TOGGLE = "com.example.dhikr_stopwatch.ACTION_TOGGLE"
    const val ACTION_RESET = "com.example.dhikr_stopwatch.ACTION_RESET"
    const val ACTION_REFRESH = "com.example.dhikr_stopwatch.ACTION_REFRESH"

    private const val H1 = 3_600_000L
    private const val H10 = 36_000_000L
    private const val REFRESH_MS = 15_000L

    private fun providerClass(id: String): Class<*> =
        if (id == TimerStore.DUROOD) DuroodWidgetProvider::class.java
        else IstighfarWidgetProvider::class.java

    private fun titleRes(id: String) =
        if (id == TimerStore.DUROOD) R.string.phrase_durood else R.string.phrase_istighfar

    private fun requestCode(id: String, slot: Int) =
        (if (id == TimerStore.DUROOD) 0 else 10) + slot

    fun formatHms(ms: Long): String {
        val s = ms / 1000
        return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
    }

    // Chronometer prints "MM:SS" (<1h), "H:MM:SS" (1-10h), "HH:MM:SS" (10h+).
    // Prefixing keeps the display in HH:MM:SS form.
    private fun chronoFormat(elapsed: Long) = when {
        elapsed < H1 -> "00:%s"
        elapsed < H10 -> "0%s"
        else -> "%s"
    }

    fun refreshAll(c: Context) = TimerStore.ALL.forEach { refresh(c, it) }

    fun refresh(c: Context, id: String) {
        val ctx = c.applicationContext
        val now = System.currentTimeMillis()
        val running = TimerStore.isRunning(ctx, id)
        val elapsed = TimerStore.elapsed(ctx, id, now)
        val cls = providerClass(id)
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, cls))
        if (ids.isEmpty()) {
            cancelRefresh(ctx, id)
            return
        }
        mgr.updateAppWidget(ids, build(ctx, id, cls, running, elapsed))
        scheduleRefresh(ctx, id, running, elapsed)
    }

    private fun build(ctx: Context, id: String, cls: Class<*>, running: Boolean, elapsed: Long): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_timer)
        rv.setTextViewText(R.id.title, ctx.getString(titleRes(id)))
        rv.setTextViewText(R.id.count, ctx.getString(R.string.count_fmt, TimerStore.count(id, elapsed)))

        if (running) {
            // Chronometer ticks by itself in the launcher: no wake-ups, no battery cost.
            val base = SystemClock.elapsedRealtime() - elapsed
            rv.setChronometer(R.id.chrono, base, chronoFormat(elapsed), true)
            rv.setViewVisibility(R.id.chrono, View.VISIBLE)
            rv.setViewVisibility(R.id.static_time, View.GONE)
        } else {
            rv.setTextViewText(R.id.static_time, formatHms(elapsed))
            rv.setViewVisibility(R.id.static_time, View.VISIBLE)
            rv.setViewVisibility(R.id.chrono, View.GONE)
        }

        rv.setTextViewText(
            R.id.btn_toggle,
            ctx.getString(if (running) R.string.pause else if (elapsed > 0) R.string.resume else R.string.start)
        )
        rv.setTextViewText(R.id.btn_reset, ctx.getString(R.string.reset))

        rv.setOnClickPendingIntent(R.id.btn_toggle, broadcast(ctx, id, cls, ACTION_TOGGLE, 1))
        rv.setOnClickPendingIntent(R.id.btn_reset, broadcast(ctx, id, cls, ACTION_RESET, 2))

        ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)?.let { launch ->
            val open = PendingIntent.getActivity(
                ctx, requestCode(id, 3), launch,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            rv.setOnClickPendingIntent(R.id.widget_root, open)
        }
        return rv
    }

    private fun broadcast(ctx: Context, id: String, cls: Class<*>, action: String, slot: Int): PendingIntent {
        val intent = Intent(ctx, cls).setAction(action)
        return PendingIntent.getBroadcast(
            ctx, requestCode(id, slot), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    // While running, wake the widget every ~15 s so the count stays fresh (the clock itself
    // ticks on its own), and right at the 1h / 10h marks so the Chronometer prefix is corrected.
    // Inexact on purpose (no exact-alarm permission), so it may fire a little late.
    private fun scheduleRefresh(ctx: Context, id: String, running: Boolean, elapsed: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = broadcast(ctx, id, providerClass(id), ACTION_REFRESH, 4)
        am.cancel(pi)
        if (!running) return
        val toThreshold = when {
            elapsed < H1 -> H1 - elapsed + 500
            elapsed < H10 -> H10 - elapsed + 500
            else -> Long.MAX_VALUE
        }
        val at = SystemClock.elapsedRealtime() + minOf(REFRESH_MS, toThreshold)
        if (Build.VERSION.SDK_INT >= 23) {
            am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME, at, pi)
        } else {
            am.set(AlarmManager.ELAPSED_REALTIME, at, pi)
        }
    }

    fun cancelRefresh(ctx: Context, id: String) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(broadcast(ctx, id, providerClass(id), ACTION_REFRESH, 4))
    }
}
