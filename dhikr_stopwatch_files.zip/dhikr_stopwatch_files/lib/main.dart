import 'dart:async';
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

const _channel = MethodChannel('dhikr/timers');
const _durood = 'durood';
const _istighfar = 'istighfar';
const _weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

// Fallback pace (ms per 100 recitations) shown only before the first snapshot loads.
const _defaultPeriod = {_durood: 150000, _istighfar: 105000};

const _duroodPhrase = 'صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ';
const _istighfarPhrase = 'أَسْتَغْفِرُ ٱللَّٰهَ';

int countFor(int periodMs, int elapsedMs) =>
    periodMs <= 0 ? 0 : elapsedMs * 100 ~/ periodMs;

void main() => runApp(const DhikrApp());

class DhikrApp extends StatelessWidget {
  const DhikrApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF0F6E56);
    ThemeData buildTheme(Brightness b) {
      final scheme = ColorScheme.fromSeed(seedColor: seed, brightness: b);
      return ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        scaffoldBackgroundColor: scheme.surfaceContainerLowest,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.transparent,
          surfaceTintColor: Colors.transparent,
          elevation: 0,
          foregroundColor: scheme.onSurface,
        ),
        cardTheme: CardThemeData(
          elevation: 0,
          color: scheme.surfaceContainerHigh,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            minimumSize: const Size(0, 46),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            minimumSize: const Size(0, 46),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
      );
    }

    return MaterialApp(
      title: 'Dhikr Stopwatch',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(Brightness.light),
      darkTheme: buildTheme(Brightness.dark),
      themeMode: ThemeMode.system,
      home: const HomePage(),
    );
  }
}

// ---------- formatting ----------

String fmtHms(int ms) {
  final s = ms ~/ 1000;
  String p(int n) => n.toString().padLeft(2, '0');
  return '${p(s ~/ 3600)}:${p((s % 3600) ~/ 60)}:${p(s % 60)}';
}

String fmtTotal(int ms) {
  if (ms < 60000) return '${ms ~/ 1000}s';
  final m = ms ~/ 60000;
  if (m < 60) return '${m}m';
  return '${m ~/ 60}h ${(m % 60).toString().padLeft(2, '0')}m';
}

// ---------- model ----------

class DayStat {
  const DayStat(this.date, this.ms);
  final DateTime date;
  final int ms;
}

class TimerSnap {
  TimerSnap({
    required this.running,
    required this.elapsedMs,
    required this.lifetimeMs,
    required this.daily,
    required this.periodMs,
    required this.onboarded,
    required this.fetchedAt,
  });

  factory TimerSnap.fromMap(String id, Map m) {
    final daily = (m['daily'] as List).map((e) {
      final d = e as Map;
      return DayStat(DateTime.parse(d['date'] as String), (d['ms'] as num).toInt());
    }).toList();
    return TimerSnap(
      running: m['running'] as bool,
      elapsedMs: (m['elapsedMs'] as num).toInt(),
      lifetimeMs: (m['lifetimeMs'] as num).toInt(),
      daily: daily,
      periodMs: (m['periodMs'] as num?)?.toInt() ?? _defaultPeriod[id]!,
      onboarded: m['onboarded'] as bool? ?? false,
      fetchedAt: DateTime.now(),
    );
  }

  final bool running;
  final int elapsedMs;
  final int lifetimeMs;
  final List<DayStat> daily;
  final int periodMs;
  final bool onboarded;
  final DateTime fetchedAt;

  int _delta(DateTime now) =>
      running ? now.difference(fetchedAt).inMilliseconds.clamp(0, 1 << 40) : 0;

  int elapsed(DateTime now) => elapsedMs + _delta(now);
  int lifetime(DateTime now) => lifetimeMs + _delta(now);
  int dayMs(int i, DateTime now) => daily[i].ms + (i == 0 ? _delta(now) : 0);
  int weekMs(DateTime now) {
    var t = 0;
    for (var i = 0; i < daily.length; i++) t += dayMs(i, now);
    return t;
  }
}

// ---------- screen ----------

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  Map<String, TimerSnap> _snaps = {};
  DateTime _now = DateTime.now();
  Timer? _ticker;
  int _ticks = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
    _askNotificationPermission();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      _ticks++;
      if (_ticks % 30 == 0) _load();
      setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ticker?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load();
  }

  Future<void> _askNotificationPermission() async {
    try {
      await _channel.invokeMethod('requestNotificationPermission');
    } on PlatformException catch (_) {}
  }

  Future<void> _load() async {
    try {
      final raw = await _channel.invokeMethod<Map>('snapshot');
      if (raw == null || !mounted) return;
      setState(() {
        _snaps = raw.map(
            (k, v) => MapEntry(k as String, TimerSnap.fromMap(k as String, v as Map)));
        _now = DateTime.now();
      });
    } on PlatformException catch (_) {}
  }

  Future<TimerSnap?> _act(String method, String id, [Map<String, Object?> extra = const {}]) async {
    try {
      final raw = await _channel.invokeMethod<Map>(method, {'id': id, ...extra});
      if (raw == null || !mounted) return null;
      final snap = TimerSnap.fromMap(id, raw);
      setState(() {
        _snaps = {..._snaps, id: snap};
        _now = DateTime.now();
      });
      return snap;
    } on PlatformException catch (_) {
      return null;
    }
  }

  Future<void> _onStartPressed(String id, String title, String phrase) async {
    final snap = _snaps[id];
    if (snap != null && !snap.onboarded) {
      final periodMs = await showModalBottomSheet<int?>(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (_) => CalibrationSheet(title: title, phrase: phrase),
      );
      if (!mounted) return;
      if (periodMs != null) {
        await _act('calibrate', id, {'periodMs': periodMs});
      } else {
        await _act('skipCalibration', id);
      }
      if (!mounted) return;
    }
    await _act('start', id);
  }

  Future<void> _onResetPressed(String id, String title, String phrase) async {
    final before = _snaps[id];
    if (before == null) return;
    final savedMs = before.elapsed(_now);
    final savedCount = countFor(before.periodMs, savedMs);
    await _act('reset', id);
    if (!mounted) return;
    if (savedMs > 0) {
      await Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => WeeklyDetailPage(
          timerId: id,
          title: title,
          phrase: phrase,
          getSnap: () => _snaps[id],
          justSavedMs: savedMs,
          justSavedCount: savedCount,
        ),
      ));
    }
  }

  void _openWeekly(String id, String title, String phrase) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => WeeklyDetailPage(
        timerId: id,
        title: title,
        phrase: phrase,
        getSnap: () => _snaps[id],
      ),
    ));
  }

  Widget _card(String id, String emoji, String title, String phrase) {
    return TimerCard(
      timerId: id,
      emoji: emoji,
      title: title,
      phrase: phrase,
      snap: _snaps[id],
      now: _now,
      onStart: () => _onStartPressed(id, title, phrase),
      onPause: () => _act('pause', id),
      onReset: () => _onResetPressed(id, title, phrase),
      onTapTime: () => _openWeekly(id, title, phrase),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 8, 4, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('As-salamu alaykum',
                      style: Theme.of(context)
                          .textTheme
                          .bodyMedium
                          ?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                  const SizedBox(height: 2),
                  Text('Dhikr Stopwatch', style: Theme.of(context).textTheme.headlineSmall),
                ],
              ),
            ),
            _card(_durood, '📿', 'Durood timer', _duroodPhrase),
            const SizedBox(height: 14),
            _card(_istighfar, '🤲', 'Istighfar timer', _istighfarPhrase),
          ],
        ),
      ),
    );
  }
}

class TimerCard extends StatelessWidget {
  const TimerCard({
    super.key,
    required this.timerId,
    required this.emoji,
    required this.title,
    required this.phrase,
    required this.snap,
    required this.now,
    required this.onStart,
    required this.onPause,
    required this.onReset,
    required this.onTapTime,
  });

  final String timerId;
  final String emoji;
  final String title;
  final String phrase;
  final TimerSnap? snap;
  final DateTime now;
  final VoidCallback onStart;
  final VoidCallback onPause;
  final VoidCallback onReset;
  final VoidCallback onTapTime;

  @override
  Widget build(BuildContext context) {
    final s = snap;
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;

    if (s == null) {
      return Card(
        child: const SizedBox(height: 190, child: Center(child: CircularProgressIndicator())),
      );
    }

    final elapsed = s.elapsed(now);
    final count = countFor(s.periodMs, elapsed);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 20,
                  backgroundColor: cs.primaryContainer,
                  child: Text(emoji, style: const TextStyle(fontSize: 18)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: tt.titleMedium),
                      Text(
                        phrase,
                        textDirection: TextDirection.rtl,
                        style: tt.bodyMedium?.copyWith(height: 1.8, color: cs.primary),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: onTapTime,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Column(
                  children: [
                    FittedBox(
                      child: Text(
                        fmtHms(elapsed),
                        style: tt.displayMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                          fontFeatures: const [FontFeature.tabularFigures()],
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('Count: $count',
                            style: tt.titleMedium?.copyWith(color: cs.onSurfaceVariant)),
                        const SizedBox(width: 6),
                        Icon(Icons.calendar_month_rounded, size: 15, color: cs.onSurfaceVariant),
                        const SizedBox(width: 2),
                        Text('week', style: tt.labelSmall?.copyWith(color: cs.onSurfaceVariant)),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: s.running
                      ? FilledButton.icon(
                          onPressed: onPause,
                          icon: const Icon(Icons.pause),
                          label: const Text('Pause'),
                        )
                      : FilledButton.icon(
                          onPressed: onStart,
                          icon: const Icon(Icons.play_arrow),
                          label: Text(elapsed > 0 ? 'Resume' : 'Start'),
                        ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: elapsed > 0 ? onReset : null,
                    icon: const Icon(Icons.restart_alt),
                    label: const Text('Reset'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _StatChip(label: 'Today', value: fmtTotal(s.dayMs(0, now))),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _StatChip(label: 'Lifetime', value: fmtTotal(s.lifetime(now))),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  const _StatChip({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: cs.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: tt.labelMedium?.copyWith(color: cs.onSurfaceVariant)),
          const SizedBox(height: 2),
          Text(value, style: tt.titleMedium),
        ],
      ),
    );
  }
}

// ---------- calibration ----------

class CalibrationSheet extends StatefulWidget {
  const CalibrationSheet({super.key, required this.title, required this.phrase});
  final String title;
  final String phrase;

  @override
  State<CalibrationSheet> createState() => _CalibrationSheetState();
}

class _CalibrationSheetState extends State<CalibrationSheet> {
  Timer? _tick;
  DateTime? _startedAt;
  int _elapsedMs = 0;
  final _manualCtrl = TextEditingController();
  String? _manualError;

  bool get _running => _startedAt != null;

  void _start() {
    setState(() {
      _startedAt = DateTime.now();
      _elapsedMs = 0;
    });
    _tick = Timer.periodic(const Duration(milliseconds: 100), (_) {
      if (!mounted || _startedAt == null) return;
      setState(() => _elapsedMs = DateTime.now().difference(_startedAt!).inMilliseconds);
    });
  }

  void _done() {
    _tick?.cancel();
    if (_elapsedMs < 3000) return; // guard against accidental instant taps
    Navigator.of(context).pop(_elapsedMs);
  }

  void _saveManual() {
    final v = int.tryParse(_manualCtrl.text.trim());
    if (v == null || v <= 0) {
      setState(() => _manualError = 'Enter seconds for 100');
      return;
    }
    Navigator.of(context).pop(v * 1000);
  }

  @override
  void dispose() {
    _tick?.cancel();
    _manualCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    final projected = _elapsedMs > 0 ? fmtTotal(_elapsedMs * 10) : null;

    return Padding(
      padding: EdgeInsets.fromLTRB(20, 4, 20, MediaQuery.of(context).viewInsets.bottom + 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 17,
                backgroundColor: cs.primaryContainer,
                child: Icon(Icons.straighten_rounded, size: 17, color: cs.primary),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Set your own pace'),
                    Text('${widget.title} · one time setup',
                        style: tt.bodySmall?.copyWith(color: cs.onSurfaceVariant)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            'Everyone recites at a different pace. Tap start, recite it 100 times at your normal pace, then tap done.',
            style: tt.bodyMedium?.copyWith(color: cs.onSurfaceVariant),
          ),
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: cs.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                Text(
                  '${(_elapsedMs ~/ 1000).toString().padLeft(2, '0')}:${((_elapsedMs % 1000) ~/ 100)}',
                  style: tt.displaySmall?.copyWith(
                    fontWeight: FontWeight.w600,
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: _running
                      ? FilledButton.icon(
                          onPressed: _elapsedMs >= 3000 ? _done : null,
                          icon: const Icon(Icons.check),
                          label: const Text("Done, I've recited 100"),
                        )
                      : FilledButton.icon(
                          onPressed: _start,
                          icon: const Icon(Icons.play_arrow),
                          label: const Text('Start timing'),
                        ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: cs.primaryContainer.withOpacity(0.5),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Icon(Icons.lightbulb_outline_rounded, size: 18, color: cs.primary),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    projected == null
                        ? '100 recitations × 10 = your time for 1000'
                        : '100 recitations took ${fmtTotal(_elapsedMs)} → about $projected for 1000',
                    style: tt.bodySmall?.copyWith(color: cs.primary),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Text('Already know your time?',
              style: tt.bodySmall?.copyWith(color: cs.onSurfaceVariant)),
          const SizedBox(height: 6),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: TextField(
                  controller: _manualCtrl,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    hintText: 'seconds for 100',
                    errorText: _manualError,
                    isDense: true,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onChanged: (_) {
                    if (_manualError != null) setState(() => _manualError = null);
                  },
                ),
              ),
              const SizedBox(width: 8),
              FilledButton(onPressed: _saveManual, child: const Text('Save')),
            ],
          ),
          const SizedBox(height: 8),
          Center(
            child: TextButton(
              onPressed: () => Navigator.of(context).pop(null),
              child: const Text('Skip, use default pace'),
            ),
          ),
        ],
      ),
    );
  }
}

// ---------- weekly detail ----------

class WeeklyDetailPage extends StatelessWidget {
  const WeeklyDetailPage({
    super.key,
    required this.timerId,
    required this.title,
    required this.phrase,
    required this.getSnap,
    this.justSavedMs,
    this.justSavedCount,
  });

  final String timerId;
  final String title;
  final String phrase;
  final TimerSnap? Function() getSnap;
  final int? justSavedMs;
  final int? justSavedCount;

  @override
  Widget build(BuildContext context) {
    final s = getSnap();
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    final now = DateTime.now();

    if (s == null) {
      return Scaffold(appBar: AppBar(title: Text(title)), body: const SizedBox());
    }

    var maxMs = 1;
    for (var i = 0; i < s.daily.length; i++) {
      final v = s.dayMs(i, now);
      if (v > maxMs) maxMs = v;
    }
    // Oldest -> newest, left to right.
    final ordered = List.generate(s.daily.length, (i) => s.daily.length - 1 - i);

    return Scaffold(
      appBar: AppBar(title: Text('$title · last 7 days')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          if (justSavedMs != null && justSavedMs! > 0)
            Container(
              margin: const EdgeInsets.only(bottom: 16),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                color: cs.secondaryContainer,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(
                children: [
                  Icon(Icons.check_circle_rounded, color: cs.secondary),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Saved ${fmtTotal(justSavedMs!)} · $justSavedCount recitations',
                            style: tt.bodyMedium?.copyWith(fontWeight: FontWeight.w600)),
                        Text('added to today · timer reset to 0',
                            style: tt.bodySmall?.copyWith(color: cs.onSecondaryContainer)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          Row(
            children: [
              Expanded(
                child: _StatChip(label: 'Last 7 days', value: fmtTotal(s.weekMs(now))),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _StatChip(label: 'Lifetime', value: fmtTotal(s.lifetime(now))),
              ),
            ],
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 130,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (final i in ordered)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          FractionallySizedBox(
                            heightFactor: (s.dayMs(i, now) / maxMs).clamp(0.03, 1.0),
                            child: Container(
                              decoration: BoxDecoration(
                                color: i == 0 ? cs.primary : cs.primary.withOpacity(0.45),
                                borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
                              ),
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            i == 0 ? 'Today' : _weekdays[s.daily[i].date.weekday - 1],
                            style: tt.labelSmall?.copyWith(
                              color: i == 0 ? cs.primary : cs.onSurfaceVariant,
                              fontWeight: i == 0 ? FontWeight.w600 : FontWeight.normal,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
              child: Column(
                children: [
                  for (var i = 0; i < s.daily.length; i++)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              i == 0 ? 'Today' : _weekdays[s.daily[i].date.weekday - 1],
                              style: tt.bodyMedium,
                            ),
                          ),
                          Text(
                            '${fmtTotal(s.dayMs(i, now))} · ${countFor(s.periodMs, s.dayMs(i, now))}',
                            style: tt.bodyMedium?.copyWith(color: cs.onSurfaceVariant),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
