import 'dart:async';
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

const _channel = MethodChannel('dhikr/timers');
const _durood = 'durood';
const _istighfar = 'istighfar';
const _weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

void main() => runApp(const DhikrApp());

class DhikrApp extends StatelessWidget {
  const DhikrApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF1B6B4F);
    return MaterialApp(
      title: 'Dhikr Stopwatch',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme:
            ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark),
      ),
      themeMode: ThemeMode.system,
      home: const HomePage(),
    );
  }
}

// ---------- formatting ----------

String fmtHms(int ms) {
  final s = ms ~/ 1000;
  String p(int n) => n.toString().padLeft(2, '0');
  return '${p(s ~/ 3600)}:${p((s % 3600) ~/ 60)}:${p(s % 60)}';
}

String fmtTotal(int ms) {
  if (ms < 60000) return '${ms ~/ 1000}s';
  final m = ms ~/ 60000;
  if (m < 60) return '${m}m';
  return '${m ~/ 60}h ${(m % 60).toString().padLeft(2, '0')}m';
}

// ---------- model ----------

class DayStat {
  const DayStat(this.date, this.ms);
  final DateTime date;
  final int ms;
}

class TimerSnap {
  TimerSnap({
    required this.running,
    required this.elapsedMs,
    required this.lifetimeMs,
    required this.daily,
    required this.fetchedAt,
  });

  factory TimerSnap.fromMap(Map m) {
    final daily = (m['daily'] as List).map((e) {
      final d = e as Map;
      return DayStat(DateTime.parse(d['date'] as String), (d['ms'] as num).toInt());
    }).toList();
    return TimerSnap(
      running: m['running'] as bool,
      elapsedMs: (m['elapsedMs'] as num).toInt(),
      lifetimeMs: (m['lifetimeMs'] as num).toInt(),
      daily: daily,
      fetchedAt: DateTime.now(),
    );
  }

  final bool running;
  final int elapsedMs;
  final int lifetimeMs;
  final List<DayStat> daily;
  final DateTime fetchedAt;

  int _delta(DateTime now) =>
      running ? now.difference(fetchedAt).inMilliseconds.clamp(0, 1 << 40) : 0;

  int elapsed(DateTime now) => elapsedMs + _delta(now);
  int lifetime(DateTime now) => lifetimeMs + _delta(now);
  int dayMs(int i, DateTime now) => daily[i].ms + (i == 0 ? _delta(now) : 0);
}

// ---------- screen ----------

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  Map<String, TimerSnap> _snaps = {};
  DateTime _now = DateTime.now();
  Timer? _ticker;
  int _ticks = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      _ticks++;
      if (_ticks % 30 == 0) _load(); // stay in sync with widget taps
      setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ticker?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load();
  }

  Future<void> _load() async {
    try {
      final raw = await _channel.invokeMethod<Map>('snapshot');
      if (raw == null || !mounted) return;
      setState(() {
        _snaps = raw.map(
            (k, v) => MapEntry(k as String, TimerSnap.fromMap(v as Map)));
        _now = DateTime.now();
      });
    } on PlatformException catch (_) {}
  }

  Future<void> _act(String method, String id) async {
    try {
      final raw = await _channel.invokeMethod<Map>(method, {'id': id});
      if (raw == null || !mounted) return;
      setState(() {
        _snaps = {..._snaps, id: TimerSnap.fromMap(raw)};
        _now = DateTime.now();
      });
    } on PlatformException catch (_) {}
  }

  Widget _card(String id, String emoji, String title, String subtitle) {
    return TimerCard(
      emoji: emoji,
      title: title,
      subtitle: subtitle,
      snap: _snaps[id],
      now: _now,
      onStart: () => _act('start', id),
      onPause: () => _act('pause', id),
      onReset: () => _act('reset', id),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Dhikr Stopwatch')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _card(_durood, '📿', 'Durood Timer', 'দরুদ'),
          const SizedBox(height: 16),
          _card(_istighfar, '🤲', 'Istighfar Timer', 'ইস্তিগফার'),
        ],
      ),
    );
  }
}

class TimerCard extends StatelessWidget {
  const TimerCard({
    super.key,
    required this.emoji,
    required this.title,
    required this.subtitle,
    required this.snap,
    required this.now,
    required this.onStart,
    required this.onPause,
    required this.onReset,
  });

  final String emoji;
  final String title;
  final String subtitle;
  final TimerSnap? snap;
  final DateTime now;
  final VoidCallback onStart;
  final VoidCallback onPause;
  final VoidCallback onReset;

  @override
  Widget build(BuildContext context) {
    final s = snap;
    if (s == null) {
      return const Card.filled(
        child: SizedBox(height: 180, child: Center(child: CircularProgressIndicator())),
      );
    }
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    final elapsed = s.elapsed(now);

    var maxMs = 1;
    for (var i = 0; i < s.daily.length; i++) {
      final v = s.dayMs(i, now);
      if (v > maxMs) maxMs = v;
    }

    return Card.filled(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(emoji, style: tt.headlineMedium),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: tt.titleLarge),
                      Text(subtitle,
                          style: tt.bodyMedium?.copyWith(color: cs.onSurfaceVariant)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Center(
              child: FittedBox(
                child: Text(
                  fmtHms(elapsed),
                  style: tt.displayMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: s.running
                      ? FilledButton.icon(
                          onPressed: onPause,
                          icon: const Icon(Icons.pause),
                          label: const Text('Pause'),
                        )
                      : FilledButton.icon(
                          onPressed: onStart,
                          icon: const Icon(Icons.play_arrow),
                          label: Text(elapsed > 0 ? 'Resume' : 'Start'),
                        ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: elapsed > 0 ? onReset : null,
                    icon: const Icon(Icons.restart_alt),
                    label: const Text('Reset'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(child: _Stat(label: 'Today', value: fmtTotal(s.dayMs(0, now)))),
                Expanded(
                    child: _Stat(label: 'Lifetime total', value: fmtTotal(s.lifetime(now)))),
              ],
            ),
            const SizedBox(height: 16),
            Text('Last 7 days', style: tt.labelLarge),
            const SizedBox(height: 8),
            for (var i = 0; i < s.daily.length; i++)
              _DayRow(
                label: i == 0
                    ? 'Today'
                    : '${_weekdays[s.daily[i].date.weekday - 1]} ${s.daily[i].date.day}',
                ms: s.dayMs(i, now),
                fraction: s.dayMs(i, now) / maxMs,
              ),
          ],
        ),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final tt = Theme.of(context).textTheme;
    final cs = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: tt.labelMedium?.copyWith(color: cs.onSurfaceVariant)),
        const SizedBox(height: 2),
        Text(value, style: tt.titleLarge),
      ],
    );
  }
}

class _DayRow extends StatelessWidget {
  const _DayRow({required this.label, required this.ms, required this.fraction});
  final String label;
  final int ms;
  final double fraction;

  @override
  Widget build(BuildContext context) {
    final tt = Theme.of(context).textTheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          SizedBox(width: 64, child: Text(label, style: tt.bodySmall)),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: fraction.clamp(0.0, 1.0),
                minHeight: 8,
              ),
            ),
          ),
          SizedBox(
            width: 64,
            child: Text(fmtTotal(ms), textAlign: TextAlign.end, style: tt.bodySmall),
          ),
        ],
      ),
    );
  }
}
